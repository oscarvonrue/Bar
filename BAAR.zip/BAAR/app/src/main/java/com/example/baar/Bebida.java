package com.example.baar;

import java.io.Serializable;

public class Bebida implements Serializable {
    private String nombre;
    private String categoria;
    private double precio;
    private String imagen;

    public Bebida(String nombre, String categoria, double precio, String imagen) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public String getImagen() {
        return imagen;
    }
}
