package com.example.baar;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Arrays originales (todas las bebidas)
        String productos[] = {"Cafe Solo", "Colacao", "Caña", "Cerveza", "Zumo Piña", "Zumo Naranja", "Whisky", "Tequila", "Agua"};
        String categorias[] = {"Desayuno", "Desayuno", "Cerveza", "Cerveza", "Zumos", "Zumos", "Licores", "Licores", "Agua"};
        int imagenes[] = {
                R.drawable.cafe, R.drawable.cafe, R.drawable.cervezas, R.drawable.cervezas,
                R.drawable.zumos, R.drawable.zumos, R.drawable.vinos, R.drawable.alcoholes, R.drawable.agua
        };

        // Arrays filtrados (sin alcohol)
        String productosSinAlcohol[] = {"Cafe Solo", "Colacao", "Zumo Piña", "Zumo Naranja", "Agua"};
        String categorias2[] = {"Desayuno", "Desayuno", "Zumos", "Zumos", "Agua"};
        int imagenes2[] = {
                R.drawable.cafe, R.drawable.cafe, R.drawable.zumos, R.drawable.zumos, R.drawable.agua
        };

        // Configurar ListView y Adaptador con la lista completa
        ListView listView = findViewById(R.id.listView1);
        BbidasAdapter adapter = new BbidasAdapter(this, productos, categorias, imagenes);
        listView.setAdapter(adapter);

        // Configurar el Switch
        Switch switcha = findViewById(R.id.switch2);
        switcha.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Cambiar a lista sin alcohol
                BbidasAdapter adapterSinAlcohol = new BbidasAdapter(this, productosSinAlcohol, categorias2, imagenes2);
                listView.setAdapter(adapterSinAlcohol);
            } else {
                // Cambiar a la lista completa
                BbidasAdapter adapterCompleto = new BbidasAdapter(this, productos, categorias, imagenes);
                listView.setAdapter(adapterCompleto);
            }
        });

        // Manejar clics en los ítems del ListView
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Obtener el nombre del producto seleccionado
                String nombreSeleccionado = (String) parent.getItemAtPosition(position);

                // Crear un Intent para pasar estos datos a la siguiente actividad
                Intent intent = new Intent(MainActivity.this, Ficha.class);
                intent.putExtra("nombre", nombreSeleccionado);

                startActivity(intent);
            }
        });
    }
}
