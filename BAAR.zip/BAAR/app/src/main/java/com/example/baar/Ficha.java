package com.example.baar;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Ficha extends AppCompatActivity {
    public int valor = 1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ficha);

        // Inicializar TextViews
        TextView nnombre, categoria, precio, num;
        nnombre = findViewById(R.id.textName);
        categoria = findViewById(R.id.textCate);
        precio = findViewById(R.id.txtprecioo);
        num = findViewById(R.id.editTextNumber);

        // Botones
        Button botonMenos, botonMas, BtnVender, BtnCancelar;
        BtnCancelar = findViewById(R.id.button5);
        BtnVender = findViewById(R.id.button3);
        botonMenos = findViewById(R.id.button);
        botonMas = findViewById(R.id.button2);

        // Establecer el valor inicial del TextView de cantidad
        num.setText(String.valueOf(valor));

        // Acción al presionar el botón de "Vender"
        BtnVender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Has vendido " + valor + " unidades", Toast.LENGTH_SHORT).show();
            }
        });

        // Acción al presionar el botón de "Cancelar"
        BtnCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Ficha.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Acción al presionar el botón "+"
        botonMas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valor++;
                num.setText(String.valueOf(valor));
            }
        });

        // Acción al presionar el botón "-"
        botonMenos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (valor > 1) {
                    valor--;
                } else {
                    Toast.makeText(Ficha.this, "No puede ser menor a 1", Toast.LENGTH_SHORT).show();
                }
                num.setText(String.valueOf(valor));
            }
        });

        // Obtener datos del Intent
        String name = getIntent().getStringExtra("nombre");

        // Establecer nombre del producto en el TextView
        nnombre.setText(name);

        // Asignar categoría y precio según el nombre del producto
        if (name.contains("Cafe") || name.contains("Colacao")) {
            categoria.setText("Desayuno");
            precio.setText("1€");
        } else if (name.contains("Caña") || name.contains("Cerveza")) {
            categoria.setText("Cerveza");
            precio.setText("2€");
        } else if (name.contains("Zumo")) {
            categoria.setText("Zumos");
            precio.setText("1.8€");
        } else if (name.contains("Whisky") || name.contains("Tequila")) {
            categoria.setText("Licores");
            precio.setText("5€");
        } else if (name.contains("Agua")) {
            categoria.setText("Refrescos");
            precio.setText("1€");
        } else {
            // Valores predeterminados para productos desconocidos
            categoria.setText("Desconocido");
            precio.setText("0€");
            Toast.makeText(this, "Producto desconocido", Toast.LENGTH_SHORT).show();
        }
    }
}
