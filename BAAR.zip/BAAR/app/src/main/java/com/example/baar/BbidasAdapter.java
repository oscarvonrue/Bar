package com.example.baar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class BbidasAdapter extends BaseAdapter {

    private Context context;
    private String[] productos;
    private String[] categorias;
    private int[] imagenes;

    // Constructor
    public BbidasAdapter(Context context, String[] productos, String[] categorias, int[] imagenes) {
        this.context = context;
        this.productos = productos;
        this.categorias = categorias;
        this.imagenes = imagenes;
    }

    @Override
    public int getCount() {
        return productos.length; // Retorna la cantidad de productos
    }

    @Override
    public Object getItem(int position) {
        return productos[position]; // Retorna el producto en la posición indicada
    }

    @Override
    public long getItemId(int position) {
        return position; // ID del ítem (posición)
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Inflar la vista del ítem si es necesario
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);
        }

        // Vincular los datos con los elementos de la vista
        ImageView imgView = convertView.findViewById(R.id.imageView);
        TextView txtNombre = convertView.findViewById(R.id.textNombre);
        TextView txtCategoria = convertView.findViewById(R.id.textCategoria);

        // Configurar los datos en los elementos
        txtNombre.setText(productos[position]);
        txtCategoria.setText(categorias[position]);
        imgView.setImageResource(imagenes[position]);

        return convertView;
    }
}
